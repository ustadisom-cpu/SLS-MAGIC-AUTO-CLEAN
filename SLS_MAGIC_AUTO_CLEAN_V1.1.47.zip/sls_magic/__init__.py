def classFactory(iface):
    from .plugin import SlsMagicPlugin
    return SlsMagicPlugin(iface)
