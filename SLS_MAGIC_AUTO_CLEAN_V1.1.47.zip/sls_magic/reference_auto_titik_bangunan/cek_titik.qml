<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis symbologyReferenceScale="-1" readOnly="0" simplifyLocal="1" hasScaleBasedVisibilityFlag="0" labelsEnabled="1" simplifyDrawingTol="1" styleCategories="AllStyleCategories" simplifyDrawingHints="0" simplifyAlgorithm="0" maxScale="0" minScale="100000000" version="3.28.13-Firenze" simplifyMaxScale="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal mode="0" startField="" durationField="" limitMode="0" endField="" fixedDuration="0" endExpression="" enabled="0" startExpression="" durationUnit="min" accumulate="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation zscale="1" extrusionEnabled="0" respectLayerSymbol="1" symbology="Line" clamping="Terrain" zoffset="0" type="IndividualFeatures" binding="Centroid" extrusion="0" showMarkerSymbolInSurfacePlots="0">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol force_rhr="0" frame_rate="10" clip_to_extent="1" name="" type="line" alpha="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" locked="0" class="SimpleLine">
          <Option type="Map">
            <Option name="align_dash_pattern" type="QString" value="0"/>
            <Option name="capstyle" type="QString" value="square"/>
            <Option name="customdash" type="QString" value="5;2"/>
            <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="customdash_unit" type="QString" value="MM"/>
            <Option name="dash_pattern_offset" type="QString" value="0"/>
            <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
            <Option name="draw_inside_polygon" type="QString" value="0"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="line_color" type="QString" value="225,89,137,255"/>
            <Option name="line_style" type="QString" value="solid"/>
            <Option name="line_width" type="QString" value="0.6"/>
            <Option name="line_width_unit" type="QString" value="MM"/>
            <Option name="offset" type="QString" value="0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="ring_filter" type="QString" value="0"/>
            <Option name="trim_distance_end" type="QString" value="0"/>
            <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_end_unit" type="QString" value="MM"/>
            <Option name="trim_distance_start" type="QString" value="0"/>
            <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="trim_distance_start_unit" type="QString" value="MM"/>
            <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
            <Option name="use_custom_dash" type="QString" value="0"/>
            <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol force_rhr="0" frame_rate="10" clip_to_extent="1" name="" type="fill" alpha="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" locked="0" class="SimpleFill">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="color" type="QString" value="225,89,137,255"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="161,64,98,255"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="style" type="QString" value="solid"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol force_rhr="0" frame_rate="10" clip_to_extent="1" name="" type="marker" alpha="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" locked="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="225,89,137,255"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="diamond"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="161,64,98,255"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.2"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="3"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 symbollevels="0" enableorderby="0" forceraster="0" type="categorizedSymbol" attr="flag_repair" referencescale="-1">
    <categories>
      <category label="Sudah Benar" render="true" type="string" symbol="0" value="0"/>
      <category label="Perlu di Edit" render="true" type="string" symbol="1" value="1"/>
    </categories>
    <symbols>
      <symbol force_rhr="0" frame_rate="10" clip_to_extent="1" name="0" type="marker" alpha="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" locked="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="51,57,215,255"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="circle"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="35,35,35,255"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="2"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" frame_rate="10" clip_to_extent="1" name="1" type="marker" alpha="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" locked="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="255,152,0,255"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="circle"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="128,17,25,255"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0.4"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="4"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <source-symbol>
      <symbol force_rhr="0" frame_rate="10" clip_to_extent="1" name="0" type="marker" alpha="1" is_animated="0">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" locked="0" class="SimpleMarker">
          <Option type="Map">
            <Option name="angle" type="QString" value="0"/>
            <Option name="cap_style" type="QString" value="square"/>
            <Option name="color" type="QString" value="145,82,45,255"/>
            <Option name="horizontal_anchor_point" type="QString" value="1"/>
            <Option name="joinstyle" type="QString" value="bevel"/>
            <Option name="name" type="QString" value="circle"/>
            <Option name="offset" type="QString" value="0,0"/>
            <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="offset_unit" type="QString" value="MM"/>
            <Option name="outline_color" type="QString" value="35,35,35,255"/>
            <Option name="outline_style" type="QString" value="solid"/>
            <Option name="outline_width" type="QString" value="0"/>
            <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="outline_width_unit" type="QString" value="MM"/>
            <Option name="scale_method" type="QString" value="diameter"/>
            <Option name="size" type="QString" value="2"/>
            <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            <Option name="size_unit" type="QString" value="MM"/>
            <Option name="vertical_anchor_point" type="QString" value="1"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </source-symbol>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style fontStrikeout="0" namedStyle="Regular" legendString="Aa" multilineHeight="1" fontFamily="Open Sans" fontSizeMapUnitScale="3x:0,0,0,0,0,0" forcedItalic="0" fontSize="10" forcedBold="0" textOpacity="1" fontUnderline="0" fontSizeUnit="Point" previewBkgrdColor="255,255,255,255" blendMode="0" fontWeight="50" fontItalic="0" multilineHeightUnit="Percentage" fontKerning="1" allowHtml="0" fontWordSpacing="0" isExpression="0" fontLetterSpacing="0" capitalization="0" textOrientation="horizontal" textColor="50,50,50,255" fieldName="no_bang" useSubstitutions="0">
        <families/>
        <text-buffer bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferDraw="1" bufferBlendMode="0" bufferColor="250,250,250,255" bufferSize="1" bufferSizeUnits="MM" bufferOpacity="1" bufferJoinStyle="128"/>
        <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskSizeUnits="MM" maskJoinStyle="128" maskedSymbolLayers="" maskEnabled="0" maskType="0" maskOpacity="1" maskSize="0"/>
        <background shapeSizeType="0" shapeRadiiY="0" shapeRotationType="0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSVGFile="" shapeJoinStyle="64" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="0" shapeSizeY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="255,255,255,255" shapeOffsetUnit="Point" shapeOpacity="1" shapeBorderWidthUnit="Point" shapeType="0" shapeOffsetY="0" shapeSizeUnit="Point" shapeOffsetX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeRotation="0" shapeRadiiUnit="Point" shapeSizeX="0" shapeBorderWidth="0" shapeBorderColor="128,128,128,255">
          <symbol force_rhr="0" frame_rate="10" clip_to_extent="1" name="markerSymbol" type="marker" alpha="1" is_animated="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" pass="0" locked="0" class="SimpleMarker">
              <Option type="Map">
                <Option name="angle" type="QString" value="0"/>
                <Option name="cap_style" type="QString" value="square"/>
                <Option name="color" type="QString" value="145,82,45,255"/>
                <Option name="horizontal_anchor_point" type="QString" value="1"/>
                <Option name="joinstyle" type="QString" value="bevel"/>
                <Option name="name" type="QString" value="circle"/>
                <Option name="offset" type="QString" value="0,0"/>
                <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="offset_unit" type="QString" value="MM"/>
                <Option name="outline_color" type="QString" value="35,35,35,255"/>
                <Option name="outline_style" type="QString" value="solid"/>
                <Option name="outline_width" type="QString" value="0"/>
                <Option name="outline_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="outline_width_unit" type="QString" value="MM"/>
                <Option name="scale_method" type="QString" value="diameter"/>
                <Option name="size" type="QString" value="2"/>
                <Option name="size_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="size_unit" type="QString" value="MM"/>
                <Option name="vertical_anchor_point" type="QString" value="1"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" type="QString" value=""/>
                  <Option name="properties"/>
                  <Option name="type" type="QString" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
          <symbol force_rhr="0" frame_rate="10" clip_to_extent="1" name="fillSymbol" type="fill" alpha="1" is_animated="0">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" pass="0" locked="0" class="SimpleFill">
              <Option type="Map">
                <Option name="border_width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="color" type="QString" value="255,255,255,255"/>
                <Option name="joinstyle" type="QString" value="bevel"/>
                <Option name="offset" type="QString" value="0,0"/>
                <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
                <Option name="offset_unit" type="QString" value="MM"/>
                <Option name="outline_color" type="QString" value="128,128,128,255"/>
                <Option name="outline_style" type="QString" value="no"/>
                <Option name="outline_width" type="QString" value="0"/>
                <Option name="outline_width_unit" type="QString" value="Point"/>
                <Option name="style" type="QString" value="solid"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" type="QString" value=""/>
                  <Option name="properties"/>
                  <Option name="type" type="QString" value="collection"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowOffsetDist="1" shadowRadiusUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowRadius="1.5" shadowScale="100" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowDraw="0" shadowOpacity="0.69999999999999996"/>
        <dd_properties>
          <Option type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format autoWrapLength="0" decimals="3" multilineAlign="3" useMaxLineLengthForAutoWrap="1" leftDirectionSymbol="&lt;" addDirectionSymbol="0" formatNumbers="0" reverseDirectionSymbol="0" plussign="0" rightDirectionSymbol=">" wrapChar="" placeDirectionSymbol="0"/>
      <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" overrunDistanceUnit="MM" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" quadOffset="4" xOffset="0" placementFlags="10" lineAnchorClipping="0" rotationUnit="AngleDegrees" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" overrunDistance="0" centroidWhole="0" distUnits="MM" priority="5" lineAnchorTextPoint="FollowPlacement" offsetType="1" preserveRotation="1" rotationAngle="0" maxCurvedCharAngleIn="25" repeatDistance="0" dist="0" offsetUnits="MM" centroidInside="0" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" geometryGenerator="" yOffset="0" placement="6" lineAnchorType="0" overlapHandling="PreventOverlap" repeatDistanceUnits="MM" allowDegraded="0" polygonPlacementFlags="2" labelOffsetMapUnitScale="3x:0,0,0,0,0,0"/>
      <rendering fontMinPixelSize="3" upsidedownLabels="0" minFeatureSize="0" zIndex="0" fontMaxPixelSize="10000" labelPerPart="0" obstacleType="1" scaleMin="0" scaleMax="0" limitNumLabels="0" maxNumLabels="2000" obstacle="1" drawLabels="1" scaleVisibility="0" unplacedVisibility="0" fontLimitPixelSize="0" obstacleFactor="1" mergeLines="0"/>
      <dd_properties>
        <Option type="Map">
          <Option name="name" type="QString" value=""/>
          <Option name="properties"/>
          <Option name="type" type="QString" value="collection"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option name="anchorPoint" type="QString" value="pole_of_inaccessibility"/>
          <Option name="blendMode" type="int" value="0"/>
          <Option name="ddProperties" type="Map">
            <Option name="name" type="QString" value=""/>
            <Option name="properties"/>
            <Option name="type" type="QString" value="collection"/>
          </Option>
          <Option name="drawToAllParts" type="bool" value="false"/>
          <Option name="enabled" type="QString" value="0"/>
          <Option name="labelAnchorPoint" type="QString" value="point_on_exterior"/>
          <Option name="lineSymbol" type="QString" value="&lt;symbol force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; type=&quot;line&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; pass=&quot;0&quot; locked=&quot;0&quot; class=&quot;SimpleLine&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;capstyle&quot; type=&quot;QString&quot; value=&quot;square&quot;/>&lt;Option name=&quot;customdash&quot; type=&quot;QString&quot; value=&quot;5;2&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;customdash_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;joinstyle&quot; type=&quot;QString&quot; value=&quot;bevel&quot;/>&lt;Option name=&quot;line_color&quot; type=&quot;QString&quot; value=&quot;60,60,60,255&quot;/>&lt;Option name=&quot;line_style&quot; type=&quot;QString&quot; value=&quot;solid&quot;/>&lt;Option name=&quot;line_width&quot; type=&quot;QString&quot; value=&quot;0.3&quot;/>&lt;Option name=&quot;line_width_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;offset&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;offset_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;ring_filter&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;trim_distance_start&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot; value=&quot;MM&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;use_custom_dash&quot; type=&quot;QString&quot; value=&quot;0&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; type=&quot;QString&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; type=&quot;QString&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
          <Option name="minLength" type="double" value="0"/>
          <Option name="minLengthMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="minLengthUnit" type="QString" value="MM"/>
          <Option name="offsetFromAnchor" type="double" value="0"/>
          <Option name="offsetFromAnchorMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="offsetFromAnchorUnit" type="QString" value="MM"/>
          <Option name="offsetFromLabel" type="double" value="0"/>
          <Option name="offsetFromLabelMapUnitScale" type="QString" value="3x:0,0,0,0,0,0"/>
          <Option name="offsetFromLabelUnit" type="QString" value="MM"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option name="embeddedWidgets/count" type="int" value="0"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer diagramType="Histogram" attributeLegend="1">
    <DiagramCategory lineSizeScale="3x:0,0,0,0,0,0" opacity="1" penColor="#000000" maxScaleDenominator="1e+08" direction="0" labelPlacementMethod="XHeight" rotationOffset="270" scaleDependency="Area" lineSizeType="MM" barWidth="5" spacing="5" diagramOrientation="Up" penWidth="0" backgroundColor="#ffffff" spacingUnit="MM" minScaleDenominator="0" height="15" sizeType="MM" penAlpha="255" backgroundAlpha="255" enabled="0" scaleBasedVisibility="0" showAxis="1" width="15" sizeScale="3x:0,0,0,0,0,0" minimumSize="0" spacingUnitScale="3x:0,0,0,0,0,0">
      <fontProperties bold="0" underline="0" style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" italic="0" strikethrough="0"/>
      <attribute color="#000000" label="" colorOpacity="1" field=""/>
      <axisSymbol>
        <symbol force_rhr="0" frame_rate="10" clip_to_extent="1" name="" type="line" alpha="1" is_animated="0">
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" type="QString" value=""/>
              <Option name="properties"/>
              <Option name="type" type="QString" value="collection"/>
            </Option>
          </data_defined_properties>
          <layer enabled="1" pass="0" locked="0" class="SimpleLine">
            <Option type="Map">
              <Option name="align_dash_pattern" type="QString" value="0"/>
              <Option name="capstyle" type="QString" value="square"/>
              <Option name="customdash" type="QString" value="5;2"/>
              <Option name="customdash_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="customdash_unit" type="QString" value="MM"/>
              <Option name="dash_pattern_offset" type="QString" value="0"/>
              <Option name="dash_pattern_offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="dash_pattern_offset_unit" type="QString" value="MM"/>
              <Option name="draw_inside_polygon" type="QString" value="0"/>
              <Option name="joinstyle" type="QString" value="bevel"/>
              <Option name="line_color" type="QString" value="35,35,35,255"/>
              <Option name="line_style" type="QString" value="solid"/>
              <Option name="line_width" type="QString" value="0.26"/>
              <Option name="line_width_unit" type="QString" value="MM"/>
              <Option name="offset" type="QString" value="0"/>
              <Option name="offset_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="offset_unit" type="QString" value="MM"/>
              <Option name="ring_filter" type="QString" value="0"/>
              <Option name="trim_distance_end" type="QString" value="0"/>
              <Option name="trim_distance_end_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="trim_distance_end_unit" type="QString" value="MM"/>
              <Option name="trim_distance_start" type="QString" value="0"/>
              <Option name="trim_distance_start_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
              <Option name="trim_distance_start_unit" type="QString" value="MM"/>
              <Option name="tweak_dash_pattern_on_corners" type="QString" value="0"/>
              <Option name="use_custom_dash" type="QString" value="0"/>
              <Option name="width_map_unit_scale" type="QString" value="3x:0,0,0,0,0,0"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" type="QString" value=""/>
                <Option name="properties"/>
                <Option name="type" type="QString" value="collection"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings obstacle="0" linePlacementFlags="18" dist="0" placement="0" priority="0" showAll="1" zIndex="0">
    <properties>
      <Option type="Map">
        <Option name="name" type="QString" value=""/>
        <Option name="properties"/>
        <Option name="type" type="QString" value="collection"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field name="fid" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="id_assignment" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="flag_repair" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="flag_position" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="flag_repair_moved" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="level_6_full_code" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="idsubsls_check" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="idsubsls" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="latitude_origin" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="longitude_origin" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="latitude_edited" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="longitude_edited" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="no_bang" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="kode_bang_value" configurationFlags="None">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="kdprov" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="nmprov" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="kdkab" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="nmkab" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="kdkec" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="nmkec" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="kddesa" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="nmdesa" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="idsls" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="nmsls" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="sls" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="kk" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="btt" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="bku" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="usaha" configurationFlags="None">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="fid" name="" index="0"/>
    <alias field="id_assignment" name="" index="1"/>
    <alias field="flag_repair" name="" index="2"/>
    <alias field="flag_position" name="" index="3"/>
    <alias field="flag_repair_moved" name="" index="4"/>
    <alias field="level_6_full_code" name="" index="5"/>
    <alias field="idsubsls_check" name="" index="6"/>
    <alias field="idsubsls" name="" index="7"/>
    <alias field="latitude_origin" name="" index="8"/>
    <alias field="longitude_origin" name="" index="9"/>
    <alias field="latitude_edited" name="" index="10"/>
    <alias field="longitude_edited" name="" index="11"/>
    <alias field="no_bang" name="" index="12"/>
    <alias field="kode_bang_value" name="" index="13"/>
    <alias field="kdprov" name="" index="14"/>
    <alias field="nmprov" name="" index="15"/>
    <alias field="kdkab" name="" index="16"/>
    <alias field="nmkab" name="" index="17"/>
    <alias field="kdkec" name="" index="18"/>
    <alias field="nmkec" name="" index="19"/>
    <alias field="kddesa" name="" index="20"/>
    <alias field="nmdesa" name="" index="21"/>
    <alias field="idsls" name="" index="22"/>
    <alias field="nmsls" name="" index="23"/>
    <alias field="sls" name="" index="24"/>
    <alias field="kk" name="" index="25"/>
    <alias field="btt" name="" index="26"/>
    <alias field="bku" name="" index="27"/>
    <alias field="usaha" name="" index="28"/>
  </aliases>
  <defaults>
    <default field="fid" applyOnUpdate="0" expression=""/>
    <default field="id_assignment" applyOnUpdate="0" expression=""/>
    <default field="flag_repair" applyOnUpdate="0" expression=""/>
    <default field="flag_position" applyOnUpdate="0" expression=""/>
    <default field="flag_repair_moved" applyOnUpdate="0" expression=""/>
    <default field="level_6_full_code" applyOnUpdate="0" expression=""/>
    <default field="idsubsls_check" applyOnUpdate="0" expression=""/>
    <default field="idsubsls" applyOnUpdate="0" expression=""/>
    <default field="latitude_origin" applyOnUpdate="0" expression=""/>
    <default field="longitude_origin" applyOnUpdate="0" expression=""/>
    <default field="latitude_edited" applyOnUpdate="0" expression=""/>
    <default field="longitude_edited" applyOnUpdate="0" expression=""/>
    <default field="no_bang" applyOnUpdate="0" expression=""/>
    <default field="kode_bang_value" applyOnUpdate="0" expression=""/>
    <default field="kdprov" applyOnUpdate="0" expression=""/>
    <default field="nmprov" applyOnUpdate="0" expression=""/>
    <default field="kdkab" applyOnUpdate="0" expression=""/>
    <default field="nmkab" applyOnUpdate="0" expression=""/>
    <default field="kdkec" applyOnUpdate="0" expression=""/>
    <default field="nmkec" applyOnUpdate="0" expression=""/>
    <default field="kddesa" applyOnUpdate="0" expression=""/>
    <default field="nmdesa" applyOnUpdate="0" expression=""/>
    <default field="idsls" applyOnUpdate="0" expression=""/>
    <default field="nmsls" applyOnUpdate="0" expression=""/>
    <default field="sls" applyOnUpdate="0" expression=""/>
    <default field="kk" applyOnUpdate="0" expression=""/>
    <default field="btt" applyOnUpdate="0" expression=""/>
    <default field="bku" applyOnUpdate="0" expression=""/>
    <default field="usaha" applyOnUpdate="0" expression=""/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="fid" unique_strength="1" constraints="3" notnull_strength="1"/>
    <constraint exp_strength="0" field="id_assignment" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="flag_repair" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="flag_position" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="flag_repair_moved" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="level_6_full_code" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="idsubsls_check" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="idsubsls" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="latitude_origin" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="longitude_origin" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="latitude_edited" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="longitude_edited" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="no_bang" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="kode_bang_value" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="kdprov" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="nmprov" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="kdkab" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="nmkab" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="kdkec" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="nmkec" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="kddesa" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="nmdesa" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="idsls" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="nmsls" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="sls" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="kk" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="btt" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="bku" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="usaha" unique_strength="0" constraints="0" notnull_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="fid" exp="" desc=""/>
    <constraint field="id_assignment" exp="" desc=""/>
    <constraint field="flag_repair" exp="" desc=""/>
    <constraint field="flag_position" exp="" desc=""/>
    <constraint field="flag_repair_moved" exp="" desc=""/>
    <constraint field="level_6_full_code" exp="" desc=""/>
    <constraint field="idsubsls_check" exp="" desc=""/>
    <constraint field="idsubsls" exp="" desc=""/>
    <constraint field="latitude_origin" exp="" desc=""/>
    <constraint field="longitude_origin" exp="" desc=""/>
    <constraint field="latitude_edited" exp="" desc=""/>
    <constraint field="longitude_edited" exp="" desc=""/>
    <constraint field="no_bang" exp="" desc=""/>
    <constraint field="kode_bang_value" exp="" desc=""/>
    <constraint field="kdprov" exp="" desc=""/>
    <constraint field="nmprov" exp="" desc=""/>
    <constraint field="kdkab" exp="" desc=""/>
    <constraint field="nmkab" exp="" desc=""/>
    <constraint field="kdkec" exp="" desc=""/>
    <constraint field="nmkec" exp="" desc=""/>
    <constraint field="kddesa" exp="" desc=""/>
    <constraint field="nmdesa" exp="" desc=""/>
    <constraint field="idsls" exp="" desc=""/>
    <constraint field="nmsls" exp="" desc=""/>
    <constraint field="sls" exp="" desc=""/>
    <constraint field="kk" exp="" desc=""/>
    <constraint field="btt" exp="" desc=""/>
    <constraint field="bku" exp="" desc=""/>
    <constraint field="usaha" exp="" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig sortOrder="0" sortExpression="" actionWidgetStyle="dropDown">
    <columns>
      <column width="-1" name="fid" hidden="0" type="field"/>
      <column width="-1" name="id_assignment" hidden="0" type="field"/>
      <column width="-1" name="flag_repair" hidden="0" type="field"/>
      <column width="-1" name="flag_position" hidden="0" type="field"/>
      <column width="-1" name="flag_repair_moved" hidden="0" type="field"/>
      <column width="-1" name="level_6_full_code" hidden="0" type="field"/>
      <column width="-1" name="idsubsls_check" hidden="0" type="field"/>
      <column width="-1" name="idsubsls" hidden="0" type="field"/>
      <column width="-1" name="latitude_origin" hidden="0" type="field"/>
      <column width="-1" name="longitude_origin" hidden="0" type="field"/>
      <column width="-1" name="latitude_edited" hidden="0" type="field"/>
      <column width="-1" name="longitude_edited" hidden="0" type="field"/>
      <column width="-1" name="no_bang" hidden="0" type="field"/>
      <column width="-1" name="kode_bang_value" hidden="0" type="field"/>
      <column width="-1" name="kdprov" hidden="0" type="field"/>
      <column width="-1" name="nmprov" hidden="0" type="field"/>
      <column width="-1" name="kdkab" hidden="0" type="field"/>
      <column width="-1" name="nmkab" hidden="0" type="field"/>
      <column width="-1" name="kdkec" hidden="0" type="field"/>
      <column width="-1" name="nmkec" hidden="0" type="field"/>
      <column width="-1" name="kddesa" hidden="0" type="field"/>
      <column width="-1" name="nmdesa" hidden="0" type="field"/>
      <column width="-1" name="idsls" hidden="0" type="field"/>
      <column width="-1" name="nmsls" hidden="0" type="field"/>
      <column width="-1" name="sls" hidden="0" type="field"/>
      <column width="-1" name="kk" hidden="0" type="field"/>
      <column width="-1" name="btt" hidden="0" type="field"/>
      <column width="-1" name="bku" hidden="0" type="field"/>
      <column width="-1" name="usaha" hidden="0" type="field"/>
      <column width="-1" hidden="1" type="actions"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
    geom = feature.geometry()
    control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable>
    <field name="bku" editable="1"/>
    <field name="btt" editable="1"/>
    <field name="fid" editable="1"/>
    <field name="flag_position" editable="1"/>
    <field name="flag_repair" editable="1"/>
    <field name="flag_repair_moved" editable="1"/>
    <field name="id_assignment" editable="1"/>
    <field name="idsls" editable="1"/>
    <field name="idsubsls" editable="1"/>
    <field name="idsubsls_check" editable="1"/>
    <field name="kddesa" editable="1"/>
    <field name="kdkab" editable="1"/>
    <field name="kdkec" editable="1"/>
    <field name="kdprov" editable="1"/>
    <field name="kk" editable="1"/>
    <field name="kode_bang_value" editable="1"/>
    <field name="latitude_edited" editable="1"/>
    <field name="latitude_origin" editable="1"/>
    <field name="level_6_full_code" editable="1"/>
    <field name="longitude_edited" editable="1"/>
    <field name="longitude_origin" editable="1"/>
    <field name="nmdesa" editable="1"/>
    <field name="nmkab" editable="1"/>
    <field name="nmkec" editable="1"/>
    <field name="nmprov" editable="1"/>
    <field name="nmsls" editable="1"/>
    <field name="no_bang" editable="1"/>
    <field name="sls" editable="1"/>
    <field name="usaha" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="bku"/>
    <field labelOnTop="0" name="btt"/>
    <field labelOnTop="0" name="fid"/>
    <field labelOnTop="0" name="flag_position"/>
    <field labelOnTop="0" name="flag_repair"/>
    <field labelOnTop="0" name="flag_repair_moved"/>
    <field labelOnTop="0" name="id_assignment"/>
    <field labelOnTop="0" name="idsls"/>
    <field labelOnTop="0" name="idsubsls"/>
    <field labelOnTop="0" name="idsubsls_check"/>
    <field labelOnTop="0" name="kddesa"/>
    <field labelOnTop="0" name="kdkab"/>
    <field labelOnTop="0" name="kdkec"/>
    <field labelOnTop="0" name="kdprov"/>
    <field labelOnTop="0" name="kk"/>
    <field labelOnTop="0" name="kode_bang_value"/>
    <field labelOnTop="0" name="latitude_edited"/>
    <field labelOnTop="0" name="latitude_origin"/>
    <field labelOnTop="0" name="level_6_full_code"/>
    <field labelOnTop="0" name="longitude_edited"/>
    <field labelOnTop="0" name="longitude_origin"/>
    <field labelOnTop="0" name="nmdesa"/>
    <field labelOnTop="0" name="nmkab"/>
    <field labelOnTop="0" name="nmkec"/>
    <field labelOnTop="0" name="nmprov"/>
    <field labelOnTop="0" name="nmsls"/>
    <field labelOnTop="0" name="no_bang"/>
    <field labelOnTop="0" name="sls"/>
    <field labelOnTop="0" name="usaha"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="bku" reuseLastValue="0"/>
    <field name="btt" reuseLastValue="0"/>
    <field name="fid" reuseLastValue="0"/>
    <field name="flag_position" reuseLastValue="0"/>
    <field name="flag_repair" reuseLastValue="0"/>
    <field name="flag_repair_moved" reuseLastValue="0"/>
    <field name="id_assignment" reuseLastValue="0"/>
    <field name="idsls" reuseLastValue="0"/>
    <field name="idsubsls" reuseLastValue="0"/>
    <field name="idsubsls_check" reuseLastValue="0"/>
    <field name="kddesa" reuseLastValue="0"/>
    <field name="kdkab" reuseLastValue="0"/>
    <field name="kdkec" reuseLastValue="0"/>
    <field name="kdprov" reuseLastValue="0"/>
    <field name="kk" reuseLastValue="0"/>
    <field name="kode_bang_value" reuseLastValue="0"/>
    <field name="latitude_edited" reuseLastValue="0"/>
    <field name="latitude_origin" reuseLastValue="0"/>
    <field name="level_6_full_code" reuseLastValue="0"/>
    <field name="longitude_edited" reuseLastValue="0"/>
    <field name="longitude_origin" reuseLastValue="0"/>
    <field name="nmdesa" reuseLastValue="0"/>
    <field name="nmkab" reuseLastValue="0"/>
    <field name="nmkec" reuseLastValue="0"/>
    <field name="nmprov" reuseLastValue="0"/>
    <field name="nmsls" reuseLastValue="0"/>
    <field name="no_bang" reuseLastValue="0"/>
    <field name="sls" reuseLastValue="0"/>
    <field name="usaha" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"level_6_full_code"</previewExpression>
  <mapTip>&lt;div style="&#xd;
padding:8px;&#xd;
background:white;&#xd;
border-radius:8px;&#xd;
border:1px solid #cccccc;&#xd;
font-family:Arial;&#xd;
font-size:12px;&#xd;
line-height:1.5;&#xd;
">&#xd;
&#xd;
&lt;b>No Bang:&lt;/b> [% "no_bang" %]&lt;br>&#xd;
&lt;b>Posisi Saat Ini:&lt;/b> [% "idsubsls" %]&lt;br>&#xd;
&lt;b>Seharusnya Berada Di:&lt;/b>&lt;br>&#xd;
[% "level_6_full_code" %]&#xd;
&#xd;
&lt;/div></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>
